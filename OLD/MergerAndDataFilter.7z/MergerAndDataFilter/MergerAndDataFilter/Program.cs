﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MergerAndDataFilter
{
    class Program
    {

        static void Main(string[] args)
        {
            string country = "T1";
            string path = @"C:\DeepSoccer\Datas\ToDo\"+country+" (";

            string[] lines = File.ReadAllLines(path + 0 + ").csv");

            Dictionary<string, int> dic = new Dictionary<string, int>();
            int j = 0;

            int numberofline = 0;

            List<string[]> list = new List<string[]>();

            for (int i = 0; i < 22; i++)
            {
                lines = File.ReadAllLines(path + i + ").csv");

                foreach (string s in lines.First().Split(','))
                {
                    if (!dic.ContainsKey(s))
                    {
                        dic.Add(s, j);
                        j++;
                    }
                }


                int c = 0;
                string[] header = lines.First().Split(',');

                foreach (string line in lines)
                {
                    if (c != 0)
                    {
                        list.Add(new string[124]);
                        int stringcount = 0;
                        foreach (string s in line.Split(','))
                        {
                            if (stringcount < header.Count())
                            {
                                list[numberofline][dic[header[stringcount]]] = s;
                            }
                            stringcount++;
                        }
                        numberofline++;
                    }
                    c++;
                }
                Console.WriteLine(i);
            }

            Console.WriteLine(list.Count);

            List<string[]> listWithoutEmpty = new List<string[]>();

            foreach (string[] li in list)
            {
                if (!string.IsNullOrEmpty(li[dic["Date"]]) && !string.IsNullOrEmpty(li[dic["HomeTeam"]])
                       && !string.IsNullOrEmpty(li[dic["AwayTeam"]]) && !string.IsNullOrEmpty(li[dic["FTAG"]])
                       && !string.IsNullOrEmpty(li[dic["FTR"]]))
                {
                    int annee = int.Parse(li[dic["Date"]].Split('/')[2]);
                    if (annee > 1900) { }
                    else
                    {
                        annee = int.Parse(li[dic["Date"]][6].ToString() + li[dic["Date"]][7].ToString());
                        if (annee > 50) { annee = 1900 + annee; }
                        else { annee = 2000 + annee; }
                    }


                    

                    string date = annee.ToString() + li[dic["Date"]][3] + li[dic["Date"]][4] + li[dic["Date"]][0] + li[dic["Date"]][1];

                    li[dic["Date"]] = date;

                    listWithoutEmpty.Add(li);
                }
            }

            IOrderedEnumerable<string[]> ordered = listWithoutEmpty.OrderBy(e => int.Parse(e[dic["Date"]])).ThenBy(e => e[dic["HomeTeam"]]);
            int oddsErrorCount = 0;
            float meanOdds = 0;
            float totalOdds = 0;
            int numberOdds = 0;
            foreach (string[] li in ordered)
            {
                string h = li[dic["BbMxH"]];
                string d = li[dic["BbMxD"]];
                string a = li[dic["BbMxA"]];

                if (!string.IsNullOrEmpty(h) && !string.IsNullOrEmpty(d)
                          && !string.IsNullOrEmpty(a))
                {
                    float H = float.Parse(h, CultureInfo.InvariantCulture);
                    float D = float.Parse(d, CultureInfo.InvariantCulture);
                    float A = float.Parse(a, CultureInfo.InvariantCulture);
                    float res = 1 / H + 1 / D + 1 / A;
                    numberOdds++;
                    totalOdds += res;
                    if (res<0.9 && res > 1.1)
                    {
                        oddsErrorCount++;
                    }
                }
            }
            meanOdds = totalOdds / numberOdds;

            Console.WriteLine("Odds error count : \0");
            Console.WriteLine(oddsErrorCount);

            Console.WriteLine("mean odds : \0");
            Console.WriteLine(meanOdds);

            string[] towrite = new string[list.Count+1];

            string dicToWrite = "";
            foreach (var i in dic)
            {
                dicToWrite += i.Key + ",";
            }

            towrite[0] = dicToWrite;

            int cc = 1;
            foreach (string[] li in ordered)
            {
                string ll = "";
                foreach (string s in li)
                {
                    ll += s + ",";
                }
                towrite[cc] = ll;
                cc++;
            }
           
            File.WriteAllLines(@"C:\DeepSoccer\Datas\ToDo\"+country+"TotalNotCrossChecked.txt", towrite);

            Console.WriteLine("finished");
            Console.ReadKey();
        }
    }
}

