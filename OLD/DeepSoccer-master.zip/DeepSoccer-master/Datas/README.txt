saison,jouneeTotale,jouneeBis,HomeTeam,AwayTeam,FTR,FTHG,FTAG,BbMxH,BbMxD,BbMxA,BbAvH,BbAvD,BbAvA,Date,HTHG,HTAG,HTR,HS,AS,HST,AST,HC,AC,

DataWithOddsD1